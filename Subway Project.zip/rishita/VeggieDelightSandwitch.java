package rishita;

public class VeggieDelightSandwitch extends SubwaySandwitch {
	
	public  String name = "Veggie Delite Sandwich";
	public int price = 100;
	public String desc = "This Sandwitch is prepared with different vegetables";
	
	public  String getName()
	{
		return name;
	}
	public  int getPrice()
	{
		return price;
	}
	public  String getDesc()
	{
		return desc;
	}

}

