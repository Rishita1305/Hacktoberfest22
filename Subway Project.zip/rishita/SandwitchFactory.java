package rishita;

public class SandwitchFactory {
	
	public static SubwaySandwitch getSandwitch(String display)
	{
		if(display.equals("Paneer Tikka Sandwich"))
			return new PaneerTikkaSandwich();
		else if(display.equals("Veggie Delite Sandwich"))
			return new VeggieDelightSandwitch();
		else if(display.equals("Tandoori Chicken Tikka Sandwich"))
			return new TandooriChickenTikkaSandwich();
		else if(display.equals("Tuna Sandwich"))
			return new TunaSandwich();
		return null;
	}

}
