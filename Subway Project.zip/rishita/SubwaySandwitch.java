package rishita;

public abstract class SubwaySandwitch {
	
	public  String name;
	public int price;
	public String desc;
	
	public abstract String getName();
	public abstract int getPrice();
	public abstract String getDesc();

}
