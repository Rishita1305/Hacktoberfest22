package rishita;

public class PaneerTikkaSandwich extends SubwaySandwitch{
	
	public  String name = "Paneer Tikka Sandwich";
	public int price = 125;
	public String desc = "This Sandwitch is prepared with Paneer Tikka";
	
	public  String getName()
	{
		return name;
	}
	public  int getPrice()
	{
		return price;
	}
	public  String getDesc()
	{
		return desc;
	}

}
