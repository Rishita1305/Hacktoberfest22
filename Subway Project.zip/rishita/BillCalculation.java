package rishita;

public interface BillCalculation {
	
	public void calculateBill();

}
