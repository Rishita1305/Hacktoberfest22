package rishita;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.TitledBorder;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;

public class SubwayFrameFinal implements ActionListener, BillCalculation{
	
	
	public String selectedSub = "";
	public int qty=0;
	String[] toppingsArr = new String[7];
	String[] addonArr = new String[4];
	
	JRadioButton both;
	
	JComboBox<String> subwayList;
	JLabel qtyValue;
	
	JCheckBox cheese;
	JCheckBox tomatoes;
    JCheckBox olives;
    JCheckBox pickles;
    JCheckBox onions;
    JCheckBox cucumber;
    JCheckBox sauces;
    
    JCheckBox chocolateCookies;
    JCheckBox thumpsUp;
    JCheckBox sprite;
    JCheckBox potatoWedges;
    JFrame frame;
    
    String billStr;
    
	
	public SubwayFrameFinal()
	{

		// TODO Auto-generated method stub
		// Create a JFrame
        frame = new JFrame("Subway");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 700);  // Increased height for better visibility
        frame.setLayout(new BorderLayout());

        // Create the heading label and add it to the top (centered by default in BorderLayout)
        JLabel Shopname = new JLabel("SUBWAY", JLabel.CENTER);
        Shopname.setFont(new Font("Arial", Font.BOLD, 18)); // Set font style and size
        frame.add(Shopname, BorderLayout.NORTH);

        // Creating a panel for keeping all the subtopics
        JPanel Types = new JPanel();
       //Types.setBorder(new TitledBorder("Type"));
        Types.setLayout(new BoxLayout(Types, BoxLayout.Y_AXIS)); // Components from top to bottom
        Types.setAlignmentX(Component.LEFT_ALIGNMENT); // Ensure alignment to the left

        // Add "Types of Subways:" label with radio buttons beside it
        JPanel typesPanel = new JPanel(new FlowLayout(FlowLayout.LEFT)); // Align components to the left
        JLabel types = new JLabel("SubwayTypes:");
        typesPanel.add(types);

        // Create radio buttons for Veg, Non-Veg, and Both
        JRadioButton vegButton = new JRadioButton("Veg");
        JRadioButton NonvegButton = new JRadioButton("Non-Veg");
        both = new JRadioButton("Both");
        both.setSelected(true);

        // Group the radio buttons so only one can be selected at a time
        ButtonGroup group = new ButtonGroup();
        group.add(vegButton);
        group.add(NonvegButton);
        group.add(both);
        //group.setSelected(both, true);
        // Add all 3 buttons to the typesPanel 
        typesPanel.add(vegButton);
        typesPanel.add(NonvegButton);
        typesPanel.add(both);

        // Add the types panel to the main Types panel
        Types.add(typesPanel);

        // Initial list of all subways
        String[] allSubways = {"Paneer Tikka Sandwich", "Veggie Delite Sandwich", "Tandoori Chicken Tikka Sandwich", "Tuna Sandwich"};
        String[] vegSubways = {"Paneer Tikka Sandwich", "Veggie Delite Sandwich"};
        String[] nonVegSubways = {"Tandoori Chicken Tikka Sandwich", "Tuna Sandwich"};

        // ComboBox for Subway names (initialized with all subways)
        JLabel names = new JLabel("Select Subway:");
        names.setAlignmentX(Component.LEFT_ALIGNMENT);
        subwayList = new JComboBox<>(allSubways);
        subwayList.setAlignmentX(Component.LEFT_ALIGNMENT);
        
     // Add ActionListeners to update subway names based on selected type
        vegButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                subwayList.setModel(new DefaultComboBoxModel<>(vegSubways));
            }
        });
     
        NonvegButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                subwayList.setModel(new DefaultComboBoxModel<>(nonVegSubways));
            }
        });

        both.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                subwayList.setModel(new DefaultComboBoxModel<>(allSubways));
            }
        });
        
        JPanel list = new JPanel(new FlowLayout(FlowLayout.LEFT));
        list.add(names);
        list.add(subwayList);
    /*    
        JPanel descPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel desc = new JLabel("This sandwitch containes vegetables tossed with spices xxxxxxxxxxx yyryrtegcbcvbcfgfcbfcgfbf czfsdgfsdg dfsdfgds");
        descPanel.add(desc);
        
        JPanel baseList = new JPanel();
        baseList.setLayout(new BoxLayout(baseList, BoxLayout.Y_AXIS));
        baseList.add(list);
        baseList.add(descPanel);
       */
        
        
        JLabel qty = new JLabel("Total Quantity:");
        qty.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel qtyPanel = new JPanel();
        qtyPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        qtyValue = new JLabel("1"); // Label to display the quantity
        JButton plusButton = new JButton("+");
        JButton minusButton = new JButton("-");
        
     // Add action listeners to the buttons
        plusButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int currentQty = Integer.parseInt(qtyValue.getText());
                qtyValue.setText(String.valueOf(currentQty + 1));
                System.out.println("Qty:"+qtyValue.getText());
            }
        });
       
        minusButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int currentQty = Integer.parseInt(qtyValue.getText());
                if (currentQty > 1) { // quantity does not go below 0
                    qtyValue.setText(String.valueOf(currentQty - 1));
                }
            }
        });
        
        qtyPanel.add(qty);
        qtyPanel.add(minusButton);
        qtyPanel.add(qtyValue);
        qtyPanel.add(plusButton);

        // Create and add toppings panel with checkboxes
        //JLabel toppings = new JLabel("Toppings: ");
        //toppings.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel topanel = new JPanel();
        topanel.setBorder(new TitledBorder("Toppings"));
        //topanel.setLayout(new BoxLayout(topanel, BoxLayout.Y_AXIS)); // Added Y_AXIS layout

        cheese = new JCheckBox("Extra Cheese");
        tomatoes = new JCheckBox("Tomatoes");
        olives = new JCheckBox("Olives");
        pickles = new JCheckBox("Pickles");
        onions = new JCheckBox("Onions");
        cucumber = new JCheckBox("Cucumber");
        sauces = new JCheckBox("Sauces");
       // JCheckBox jcblank = new JCheckBox("     ");

        // Add the checkboxes for toppings
        topanel.add(cheese);
        topanel.add(tomatoes);
        topanel.add(olives);
        topanel.add(pickles);
        topanel.add(onions);
        topanel.add(cucumber);
        topanel.add(sauces);
        //topanel.add(jcblank);

        // Create and add add-ons panel with checkboxes
        //JLabel addons = new JLabel("AddOns: ");
        //addons.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel addonPanel = new JPanel();
        addonPanel.setBorder(new TitledBorder("Add-Ons"));
        //addonPanel.setLayout(new BoxLayout(addonPanel, BoxLayout.Y_AXIS)); // Added Y_AXIS layout

        chocolateCookies = new JCheckBox("Chocolate Cookies");
        thumpsUp = new JCheckBox("Thums Up");
        sprite = new JCheckBox("Sprite");
        potatoWedges = new JCheckBox("Potato Wedges");

        // Add the checkboxes for add-ons
        addonPanel.add(chocolateCookies);
        addonPanel.add(thumpsUp);
        addonPanel.add(sprite);
        addonPanel.add(potatoWedges);

        // Create and add submit button
        JButton submitButton = new JButton("Submit");
        //JButton clearButton = new JButton("Clear");
        JPanel bPanel = new JPanel(new FlowLayout());
       // bPanel.add(clearButton);
        bPanel.add(submitButton);
        
        
        submitButton.addActionListener(this);
            
            
        
     // Add all sub-panels to the main Types panel
        //Types.add(names);
        //Types.add(subwayList); // Add the dropdown list
        Types.add(list);
        Types.add(Box.createRigidArea(new Dimension(0, 10)));
        Types.add(qtyPanel);
        Types.add(Box.createRigidArea(new Dimension(0, 10)));
        //Types.add(toppings);
        Types.add(topanel); // Add toppings checkboxes
        Types.add(Box.createRigidArea(new Dimension(0, 10)));
        //Types.add(addons);
        Types.add(addonPanel); // Add add-ons checkboxes
        //Types.add(Box.createRigidArea(new Dimension(0, 10)));
        Types.add(bPanel);

        // Add the subheading panel to the center of the frame
        frame.add(Types, BorderLayout.CENTER);

        // Make the frame visible
        frame.setVisible(true);
	
	}

	public static void main(String[] args) {
		
		SubwayFrameFinal sff = new SubwayFrameFinal();
		// Display the bill in a new dialog
        
		
	}
	

	
	public void actionPerformed(ActionEvent e) {
		
		System.out.println("In AF");
		
        // Collect all order details
		selectedSub = (String) subwayList.getSelectedItem();
        qty = Integer.parseInt(qtyValue.getText());
        System.out.println("Qty bill:"+qtyValue.getText());

        //Toppings
        int count=0;
               
        if (cheese.isSelected())
        {
    		toppingsArr[count] = "Extra Cheese";
    		count++;
        }
        
        if (tomatoes.isSelected())
        {
    		toppingsArr[count] = "Tomatoes";
    		count++;
        }
        if (olives.isSelected())
        {
    		toppingsArr[count] = "Olives";
    		count++;
        }
        	
        if (pickles.isSelected())
        {
    		toppingsArr[count] = "Pickles";
    		count++;
        }
        if (onions.isSelected())
        {
    		toppingsArr[count] = "Onions";
    		count++;
        }
        
        if (cucumber.isSelected())
        {
    		toppingsArr[count] = "Cucumber";
    		count++;
        }
     
        if (sauces.isSelected())
        {
    		toppingsArr[count] = "Sauces";
    		count++;
        }
    
        //Add Ons
        
        count=0;
    		
        if (chocolateCookies.isSelected())
        {
    		addonArr[count] = "Chocolate Cookies";
    		count++;
        }
   
        if (thumpsUp.isSelected())
        {
        	addonArr[count] = "Thums Up";
    		count++;
        }
       
        if (sprite.isSelected())
        {
        	addonArr[count] = "Sprite";
    		count++;
        }
           		
        if (potatoWedges.isSelected())
        {
        	addonArr[count] = "Potato Wedges";
    		count++;
        }
  
        for(int i=0 ; i<toppingsArr.length; i++)
        	System.out.println(toppingsArr[i]);
        
        for(int i=0 ; i<addonArr.length; i++)
        	System.out.println(addonArr[i]);
        
        
        
        calculateBill();
       
     // Create the pop-up dialog
        JDialog popupDialog = new JDialog(frame, "Subway Bill", true);
        popupDialog.setSize(700, 600);
        popupDialog.setLayout(null);
        JTextArea area = new JTextArea();
        area.setFont(new Font(Font.MONOSPACED, Font.BOLD, 13));
        
        area.setText(billStr);
        area.setBounds(50, 50, 550, 500);
        popupDialog.add(area);

        // Set the position of the pop-up dialog relative to the main frame
        popupDialog.setLocationRelativeTo(frame);
        popupDialog.setVisible(true);

        clearFields();
              
        
	} 
	
	public void calculateBill()
	{
		System.out.println("*"+selectedSub+"*");
		SubwaySandwitch sandwitch = SandwitchFactory.getSandwitch(selectedSub);
		int total =0;
		
		int subtotal = qty*sandwitch.getPrice();
		System.out.println("Qty in Calc: "+subtotal);
		       
		billStr = "Subway Bill"+"\n\n" +
                "Item  "+"\t\t\t\t\t"+"Qty."+"\t"+"Price"+"\t"+"Total"+"\n"+
				"----------------------------------------------------------------------------------------------------------"+"\n"+
               padString(41, selectedSub,false) +  padString(9, new Integer(qty), false) +  padString(8, new Integer(sandwitch.getPrice()),false) + subtotal  + ""+
               "\n\nToppings:\n"+
               "-------------\n";
				total= total +sandwitch.getPrice()*qty;
               for(int i=0; i<toppingsArr.length; i++)
               {
            	   if(toppingsArr[i]!=null)
            		{
            		   String topping= toppingsArr[i];
            		   Integer price = Prices.toppings.get(topping);
            		   int intPrice= price.intValue();
            		   total=total+intPrice;
            		   billStr = billStr + padString(41,topping, false) + padString(9, new Integer(1), false)+ padString(9, new Integer(intPrice), true)+intPrice+"\n";
            		   
    			   }
            			   
               }
               
               billStr = billStr+ 
    		   "\nAdd-Ons:\n"+
               "-------------\n";	   
               
               for(int i=0; i<addonArr.length; i++)
               {
            	   if(addonArr[i]!=null)
            		{
            		   String addon= addonArr[i];
            		   Integer price = Prices.addons.get(addon);
            		   int intPrice= price.intValue();
            		   total = total + intPrice;
            		   billStr = billStr+padString(41,addon, false)+ padString(9, new Integer(1), false) + padString(9, new Integer(intPrice), true) + intPrice +"\n";
            		   
    			   }
            			   
               }
               billStr = billStr+ 
            		   "\n"+padString(58, "Total:", false) + total +"\n"+
                       "---------------------------------------------------------------------------------------------------------\n";	   
                   System.out.println("Total:"+total);    
               
				/* "Subway Name: " + selectedSubway + "\n" +
                "Quantity: " + quantity + "\n" +
                "Toppings: " + (toppingsList.length() > 0 ? toppingsList : "None") + "\n" +
                "Add-Ons: " + (addonsList.length() > 0 ? addonsList : "None") + "\n" +*/
               billStr = billStr+"\nThank you for ordering from Subway!";
	}
	
	public void clearFields()
	{
		 cheese.setSelected(false);
		 tomatoes.setSelected(false);
	     olives.setSelected(false);
	     pickles.setSelected(false);
	     onions.setSelected(false);
	     cucumber.setSelected(false);
	     sauces.setSelected(false);
	    
	     chocolateCookies.setSelected(false);
	     thumpsUp.setSelected(false);
	     sprite.setSelected(false);
	     potatoWedges.setSelected(false);
	     for( int i = 0; i < toppingsArr.length; i++)
	     {
	    	 toppingsArr[i]=null;
	     }
	     for( int i = 0; i < addonArr.length; i++)
	     {
	    	 addonArr[i]=null;
	     }
	     qtyValue.setText("1");
	     both.setSelected(true);
	     both.doClick();
	}


	public static String padString(int padCount, Object obj, boolean flag)
	{
		int d;
		String prefix="";
		int count=0;
		if(flag==true)
		{
			if (obj instanceof Integer)
			{
				d=((Integer)obj).intValue();
				if (d < 10)
				{
					//System.out.println("In less than 10");
					prefix="  ";
					count=2;
				}
				else if (d < 100)
				{
					prefix=" ";
					count=1;
				}
			}
		}
		//System.out.println("*"+prefix+"*");
		int length = obj.toString().length();
		String rpt = " ".repeat(padCount-length-count);
		return prefix+obj.toString()+rpt;
		
	}

}
