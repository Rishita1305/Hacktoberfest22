package rishita;

import java.util.HashMap;

public class Prices {
	
public static HashMap<String, Integer> toppings;
public static HashMap<String, Integer> addons;

	static {
		
		toppings = new HashMap();
		
		toppings.put("Extra Cheese", Integer.valueOf(20));
		toppings.put("Tomatoes", Integer.valueOf(10));
		toppings.put("Olives", Integer.valueOf(20));
		toppings.put("Pickles", Integer.valueOf(20));
		toppings.put("Onions", Integer.valueOf(10));
		toppings.put("Cucumber", Integer.valueOf(10));
		toppings.put("Sauces", Integer.valueOf(15));
		
		addons = new HashMap();
		addons.put("Chocolate Cookies", Integer.valueOf(25));
		addons.put("Thums Up", Integer.valueOf(30));
		addons.put("Sprite", Integer.valueOf(30));
		addons.put("Potato Wedges", Integer.valueOf(25));
		
		
	}


}
