package rishita;

public class TandooriChickenTikkaSandwich extends SubwaySandwitch{
	
	public  String name = "Tandoori Chicken Tikka Sandwich";
	public int price = 200;
	public String desc = "This Sandwitch is prepared with Tandoori Chicken pieces";
	
	public  String getName()
	{
		return name;
	}
	public  int getPrice()
	{
		return price;
	}
	public  String getDesc()
	{
		return desc;
	}

}